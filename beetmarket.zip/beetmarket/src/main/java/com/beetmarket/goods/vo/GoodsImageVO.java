package com.beetmarket.goods.vo;

import lombok.Data;

@Data
public class GoodsImageVO {

	// goodsImage
	private Long goodsNo;
	private Long goodsImageNo;
	private String goodsImageName;
	
}
