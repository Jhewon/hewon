package com.beetmarket.goods.vo;

import lombok.Data;

@Data
public class GoodsInfoVO {

	// goodsInfo
	private Long goodsNo;
	private Long goodsIngoNo;
	private String goodsInfoName;
	private String goodsInfoCon;
	
}
