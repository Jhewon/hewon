package com.beetmarket.goods.vo;

import lombok.Data;

@Data
public class GoodsLikeVO {

	// goodsLike
	private Long goodsNo;
	private Long goodsLikeNo;
	
	// foringKey
	private String id;
	
}
