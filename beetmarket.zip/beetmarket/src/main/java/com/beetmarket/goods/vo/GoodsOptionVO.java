package com.beetmarket.goods.vo;

import lombok.Data;

@Data
public class GoodsOptionVO {

	// goodsOption
	private Long goodsNo;
	private Long goodsOptNo;
	private Long goodsOptPrice;
	private String goodsOptName;
	
}
