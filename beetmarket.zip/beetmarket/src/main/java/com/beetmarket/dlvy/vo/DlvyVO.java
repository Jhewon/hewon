package com.beetmarket.dlvy.vo;

import lombok.Data;

@Data
public class DlvyVO {
	private long dlvyAddrNo,postNo,basic;
	private String dlvyName,id,recipient,tel,addr,addrDetail;
}
