package com.beetmarket.main.vo;

public class MainSearchVO {

}
