package com.beetmarket.category.vo;

import lombok.Data;

@Data
public class CategoryVO {

	private Integer cateHighNo;
	private Integer cateMidNo;
	private Integer cateLowNo;
	private String categoryName;
	
}
